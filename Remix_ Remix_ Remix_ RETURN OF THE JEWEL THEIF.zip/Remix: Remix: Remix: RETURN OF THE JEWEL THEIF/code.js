var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["ca171aac-1207-40ce-888b-97923acce273","ae612975-cc37-4ac3-96dc-9ba3a48d324e","d9dcd64a-5589-4ba9-9db7-81737f0adf78","10d9320d-0476-4309-aa37-fe6a01025175"],"propsByKey":{"ca171aac-1207-40ce-888b-97923acce273":{"name":"kid_17_1","sourceUrl":"assets/api/v1/animation-library/gamelab/hpptVGX.lYZA807Hg84QqSng5y7UF6xa/category_people/kid_17.png","frameSize":{"x":208,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"hpptVGX.lYZA807Hg84QqSng5y7UF6xa","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":208,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/hpptVGX.lYZA807Hg84QqSng5y7UF6xa/category_people/kid_17.png"},"ae612975-cc37-4ac3-96dc-9ba3a48d324e":{"name":"gameplay_purplediamond_1","sourceUrl":"assets/api/v1/animation-library/gamelab/dmHXimVUN6NkkgGu6Ojoow2mldVDI2ai/category_video_games/gameplay_purplediamond.png","frameSize":{"x":400,"y":383},"frameCount":1,"looping":true,"frameDelay":2,"version":"dmHXimVUN6NkkgGu6Ojoow2mldVDI2ai","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":383},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dmHXimVUN6NkkgGu6Ojoow2mldVDI2ai/category_video_games/gameplay_purplediamond.png"},"d9dcd64a-5589-4ba9-9db7-81737f0adf78":{"name":"kid_41_1","sourceUrl":"assets/api/v1/animation-library/gamelab/I4gAU8vs6QygAft6jqGxm7FyK4j6hDop/category_people/kid_41.png","frameSize":{"x":210,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"I4gAU8vs6QygAft6jqGxm7FyK4j6hDop","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":210,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/I4gAU8vs6QygAft6jqGxm7FyK4j6hDop/category_people/kid_41.png"},"10d9320d-0476-4309-aa37-fe6a01025175":{"name":"sticker_14_1","sourceUrl":"assets/api/v1/animation-library/gamelab/1ve8xcSUavvVvLC6Vl.mojAV9PqyYTDU/category_stickers/sticker_14.png","frameSize":{"x":246,"y":192},"frameCount":1,"looping":true,"frameDelay":2,"version":"1ve8xcSUavvVvLC6Vl.mojAV9PqyYTDU","categories":["stickers"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":246,"y":192},"rootRelativePath":"assets/api/v1/animation-library/gamelab/1ve8xcSUavvVvLC6Vl.mojAV9PqyYTDU/category_stickers/sticker_14.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var Thief = createSprite(20,380,20,20);
    Thief.setAnimation("kid_41_1");
    Thief.scale = 0.15;

var Diamond = createSprite(380,20,20,20);
    Diamond.setAnimation("sticker_14_1");
    Diamond.scale = 0.1;
    
var Laser1 = createSprite(110,250,200,5);
    Laser1.shapeColor = "Red";
    Laser1.velocityY = -5;

var Laser2 = createSprite(290,200,200,5);
    Laser2.shapeColor = "Red";
    Laser2.velocityY = +5;
    
function draw() {
  background("lightblue");
  
createEdgeSprites();
  Thief.bounceOff(edges);
  Laser1.bounceOff(edges);
  Laser2.bounceOff(edges);
  
  Thief.velocityX = 0;
  Thief.velocityY = 0;
  
  if (keyDown("RIGHT_ARROW")){
    Thief.velocityX = +6;
  }
  
  if (keyDown("LEFT_ARROW")){
    Thief.velocityX = -6;
  }
  
  if (keyDown("UP_ARROW")){
    Thief.velocityY= -6;
  }
  
  if (keyDown("DOWN_ARROW")){
    Thief.velocityY = +6;
  }
                                
  if (Thief.isTouching(Diamond)){
    background("red");
    textSize(45);
    stroke("");
    fill("Blue");
playSpeech(" Diamond is Stolen", "female", "English");
       text("Diamond is stolen",10,200);
    Laser1.shapeColor = "white";
   Laser2.shapeColor = "white";
    Laser1.setVelocity(0,0);
    Laser2.setVelocity(0,0);
    Thief.setVelocity(0,0);
  playSound("assets/default.mp3", false);

      
    
  }
  
  
  if (Thief.isTouching(Laser1)||(Thief.isTouching(Laser2))){
    background("lightblue");
   textSize(50);
   stroke("blue");
   fill("red");
  text("Thief is caught", 30,200);
 playSpeech("Theif is Caught", "female", "English");
   playSound("assets/default.mp3", false);
    
   Laser1.setVelocity(0,0);
  Laser2.setVelocity(0,0);
  Thief.setVelocity(0,0);
  }
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
